-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2022 at 03:21 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jewellery`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `unique_id` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `mcolor` varchar(255) DEFAULT NULL,
  `appx_gram` varchar(255) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `client_name`, `unique_id`, `date`, `mcolor`, `appx_gram`, `comments`, `image`) VALUES
(1, 'Eagan Hubbard', 'Hic numquam alias ni', '28-May-2014', '1', 'Facere sit dolor vol', 'Nemo deserunt ullamc', '16718047611.jpg'),
(2, 'Garrison Mckee', 'Expedita voluptatem', '31-Jan-2002', '3', 'Laboriosam maiores', 'Consectetur nulla du', '16718047971.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `product_name` varchar(255) DEFAULT NULL,
  `size` varchar(255) DEFAULT NULL,
  `karat` varchar(255) DEFAULT NULL,
  `mcolor` varchar(255) DEFAULT NULL,
  `appxgram` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_name`, `size`, `karat`, `mcolor`, `appxgram`) VALUES
(1, '1', 'Chandler Hebert', 'Fugit vel quaerat q', '2', '2', 'Eum qui dolorem odit'),
(2, '2', 'Colby Stafford', 'Ut assumenda tempore', '1', '2', 'Laboriosam voluptat'),
(3, '2', 'MacKenzie Snyder', 'Quaerat aut consequa', '8', 'Yellow', 'Enim doloremque inve'),
(4, '2', 'Dennis Merrill', 'Ipsum autem odit qu', 'K', 'Red', 'Doloremque quaerat a');

-- --------------------------------------------------------

--
-- Table structure for table `worker`
--

CREATE TABLE `worker` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `adhar` varchar(255) DEFAULT NULL,
  `working_id` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `worker_iamge` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `worker`
--

INSERT INTO `worker` (`id`, `name`, `phone`, `place`, `adhar`, `working_id`, `email`, `worker_iamge`) VALUES
(6, 'Yolanda Roman', '+1 (713) 132-8665', 'Sunt molestiae tota', '97', 'Et aut voluptas iure', 'roxi@mailinator.com', '16718041252066267484.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `worker`
--
ALTER TABLE `worker`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `worker`
--
ALTER TABLE `worker`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
