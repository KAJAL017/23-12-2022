<?php echo $__env->make('admin.main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="mrg_tp"></div>

<div class="dashboard_min">
    <div class="container-fluid">
        <div class="worker_list_sec">
            <div class="worker_list_top">
                <div class="worker_list_left">
                    <div class="worker_list_input">
                        <a href="<?php echo e(route('worker_form')); ?>"><input type="submit" placeholder="Add Worker"
                                value="Add Worker"></a>
                        <em class="sh_img"><img src="<?php echo e(url('public')); ?>/assets/images/plus.png" alt=""></em>
                    </div>
                </div>
            </div>
            <div class="worker_list_panel">
                <div class="worker_list_tab_hed">
                    <div class="row">
                        
                        <div class="col "><b>Actions</b></div>
                        <div class="col "><b>Aadhaar</b></div>
                        <div class="col "><b>Place</b></div>
                        <div class="col "><b>Phone</b></div>
                        <div class="col "><b>Working ID</b></div>
                        <div class="col "><b>Mail ID</b></div>
                        <div class="col "><b>User Name</b></div>
                    </div>
                </div>
                <?php $__currentLoopData = $worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="worker_list_tab_itm">
                    <div class="row">
                        <div class="col">
                            <span class="hide_big">Actions</span>
                            <div class="ac_di">
                                <ul>
                                    
                                    <li><a href="<?php echo e(route('edit_worker',[$item->id])); ?>"><img src="<?php echo e(url('public')); ?>/assets/images/action2.png" alt=""></a></li>
                                    <li ><a href="<?php echo e(route('delete_worker',[$item->id])); ?>"><img src="<?php echo e(url('public')); ?>/assets/images/action3.png" alt=""></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col">
                            <p><?php echo e($item->adhar); ?></p>
                        </div>
                        <div class="col">
                            <p><?php echo e($item->place); ?></p>
                        </div>
                        <div class="col">
                            <p><?php echo e($item->phone); ?></p>
                        </div>
                        <div class="col">
                            <p><?php echo e($item->working_id); ?> </p>
                        </div>
                        <div class="col">
                            <p><?php echo e($item->email); ?></p>
                        </div>
                        <div class="col">
                            <p class="user_nm mx-5"><?php echo e($item->name); ?><em><img src="<?php echo e(url('public')); ?>/uploads/<?php echo e($item->worker_iamge); ?>" class="ml-2" alt=""></em></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.main.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\laravel\jewellery\resources\views/admin/pages/worker/worker.blade.php ENDPATH**/ ?>