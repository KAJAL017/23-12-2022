<?php echo $__env->make('admin.main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<div class="mrg_tp"></div>

<div class="dashboard_min">
    <div class="container-fluid">
        <div class="worker_list_sec">
            
            <div class="worker_list_panel">
                <div class="worker_list_tab_hed">
                    <div class="row">
                        
                        <div class="col "><b>Actions</b></div>
                        <div class="col "><b>Client Name</b></div>
                        <div class="col "><b>Uniqui Id</b></div>
                        <div class="col "><b>Date</b></div>
                        <div class="col "><b>Metal Color</b></div>
                        
                    </div>
                </div>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="worker_list_tab_itm">
                    <div class="row">
                        <div class="col">
                            <span class="hide_big">Actions</span>
                            <div class="ac_di">
                                <ul>
                                    <li><a href="<?php echo e(route('view_order_form',[$item->id])); ?>"><img src="<?php echo e(url('public')); ?>/assets/images/action1.png" alt=""></a>
                                    </li>
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="col">
                            <p><?php echo e($item->client_name); ?></p>
                        </div>
                        <div class="col">
                            <p><?php echo e($item->unique_id); ?></p>
                        </div>
                        <div class="col">
                            <p><?php echo e($item->date); ?></p>
                        </div>
                        <div class="col">
                            <p> <?php if($item->mcolor==1): ?> RED <?php else: ?> YELLOW <?php endif; ?> </p>
                        </div>


                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
</div

<?php echo $__env->make('admin.main.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH C:\xampp\htdocs\jewellery\resources\views/admin/pages/order/order_history.blade.php ENDPATH**/ ?>