
// $(".navbar-toggler").click(function(){
//   $(".navbar-toggler").toggleClass("showtoggle");
// });	


  $(document).ready(function(){
    $("#mobile_menu").click(function(){
        $("#mobile_menu_dv").slideToggle();
    });
});
