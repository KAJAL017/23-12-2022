@include('admin.main.header')

<div class="mrg_tp"></div>

<div class="dashboard_min">
    <div class="container-fluid">
        <div class="dashboard_panel">
            <div class="dashboard_left">
                <div class="das_left_inr">
                @if (Session::get('role') == 1 )
                <div class="das_menu">
                    <h4> Order Book</h4>
                    <ul>
                        <li class="{{ (request()->route()->named('order_form')) ? 'activ' : '' }}" ><a href="{{ route('order_form') }}">Order Form</a></li>
                        <li class="{{ (request()->route()->named('order_history')) ? 'activ' : '' }}"><a href="{{ route('order_history') }}">Order History</a></li>
                        <li ><a href="#url">Order Status</a></li>
                    </ul>
                </div>
                @endif
                    @if (Session::get('role') == 2 )
                    <div class="das_menu">
                        <h4> Manufacture</h4>
                        <ul>
                            <li><a href="manufacture-filling-form.html">Filing</a></li>
                            <li><a href="manufacture-mounting.html">Mounting</a></li>
                            <li><a href="manufacture-setting-form.html">Setting</a></li>
                            <li><a href="manufacture-final-polish.html">Final Polish</a></li>
                        </ul>
                    </div>
                    @endif
         
                </div>
            </div>
            <div class="dashboard_right">
                <div class="das_right_inr">
                    <div class="das_tab_menu">
                        <ul>
                            <li class="actv"><a href="order-form.html">Order Form</a></li>
                            <li><a href="order-history.html">Order History</a></li>
                            <li><a href="#url">Order Status</a></li>
                        </ul>
                    </div>
                    <div class="das_frm_panel">
                        <form action="{{ route('store_order') }}" method="POST" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="das_frm_bx">
                                <div class="frm_tp">
                                    <h4>Order No : 13202</h4>
                                </div>
                                <div class="frm_inp_top">
                                    <div class="row">
                                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Client Name</span>
                                                <input type="text" placeholder="Full Name" name="cname">
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Unique ID</span>
                                                <input type="text" placeholder="13202 | Shahid | Ring" name="unique_id">
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Date</span>
                                                <input type="text" placeholder="26| 11 | 2022" class="datepicker"
                                                    name="date">
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="frm_inp_body">
                                    <div class="row">
                                        <div class="col-xl-3 col-lg-2 col-md-3 col-sm-12">
                                            <div class="input_bx">
                                                <span>Product Name</span>
                                                <span class="multi-select-custom"></span>
                                                <input type="text" placeholder="Enter Product Name" name="pname[]">
                                            </div>
                                        </div>
                                        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                                            <div class="input_bx">
                                                <span>Size</span>
                                                <input type="text" placeholder="Enter Size" name="size[]">
                                            </div>
                                        </div>
                                        <div class="col-xl-2 col-lg-2 col-md-3 col-sm-12">
                                            <div class="input_bx">
                                                <span>Appx Gram</span>
                                                <input type="text" placeholder="Enter Size" name="apxgram[]">
                                            </div>
                                        </div>
                                        <div class="col-xl-2 col-lg-4 col-md-3 col-sm-12">
                                            <div class="input_bx">
                                                <span>Metal colour</span>
                                                <select name="mcolor[]">
                                                    <option value="1">Red</option>
                                                    <option value="2">Yellow</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-xl-2 col-lg-4 col-md-3 col-sm-12">
                                            <div class="input_bx">
                                                <span>Karat ( Purity )</span>
                                                <select name="karat">
                                                    <option value="1">18K</option>
                                                    <option value="2">22K</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-1  mt-5">
                                            <div class="form-group ">
                                                <button class="btn btn-primary" type="button"
                                                    style="font-size: 2 0px; padding: 0px 10px;"
                                                    onclick="appendform()">+</button>
                                            </div>
                                        </div>
                                    </div>
                                        <div id="addappend"></div>


                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12    ">
                                            <div class="input_bx">
                                                <span>Approx Weight Grams</span>
                                                <input type="text" placeholder="Enter here" value="9" name="appx_weight">
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Comments</span>
                                                <input type="text" placeholder="Enter here" value="Text" name="comment">
                                            </div>
                                        </div>
                                        <div class="col-xl-5 col-lg-6 col-md-12 col-sm-12">
                                            <div class="uplodimg">
                                                <span class="uplode_spa"><small>Upload File</small></span>
                                                <div class="uplodimgfil">
                                                    <input type="file" name="img" id="file-1"
                                                        class="inputfile "
                                                     />
                                                    <label for="file-1">Drag and Drop or <b>Browse</b> to upload
                                                        <em><img src="assets/images/gall.png" alt=""></em>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-md-12">
                                        <div class="sub_btn cc_top_btn">
                                            <button style="border:none" type="submit"  class="btn_cc">Submit
                                                    <em><img src="assets/images/btn_icon.png" alt=""></em></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>

@include('admin.main.footer')
