<?php echo $__env->make('admin.main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="mrg_tp"></div>
<div class="dashboard_min">
    <div class="container-fluid">
        <div class="dashboard_panel">

            <div class="dashboard_right w-100">
                <div class="das_right_inr ">
                    <div class="">
                        <ul class="">
                            <h2><li class=" mt-5"><a href="order-form.html">Add Worker</a></li></h2>

                        </ul>
                    </div>
                    <div class="das_frm_panel ">
                        <form action="<?php echo e(route('add_worker')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="das_frm_bx mt-5">
                                <div class="frm_inp_body">
                                    <div class="row">

                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>User Name</span>
                                                <input type="text" placeholder="Worker Name" name="name" required>
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>User Phone</span>
                                                <input type="text" placeholder="Worker Phone" name="phone" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Place</span>
                                                <input type="text" placeholder="Worker Place" name="place" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Adhar</span>
                                                <input type="number" placeholder="Worker Adhar" name="adhar" readonly>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Working Id</span>
                                                <input type="text" placeholder="Working Id" name="working_id" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Email</span>
                                                <input type="email" placeholder="Working email" name="email" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                            <div class="uplodimg">
                                                <span class="uplode_spa"><small>Worker Image</small></span>
                                                <div class="uplodimgfil">
                                                    <input type="file" name="worker_iamge" id="file-1"
                                                        class="inputfile inputfile-1"
                                                        data-multiple-caption="{count} files selected" required>
                                                    <label for="file-1">Drag and Drop or <b>Browse</b> to upload
                                                        <em><img src="assets/images/gall.png" alt=""></em>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">

                                        <div class=" cc_top_btn">
                                            <button style="border:none;margin-top:123px;height:53px;text-align:center;" type="submit" class="btn_cc" >Submit
                                                    <em><img src="assets/images/btn_icon.png" alt=""></em></button>
                                        </div>
                                        </div>



                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('admin.main.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php /**PATH C:\xampp\htdocs\laravel\jewellery\resources\views/admin/pages/worker/worker_form.blade.php ENDPATH**/ ?>