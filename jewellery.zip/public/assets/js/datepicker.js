$(function() {
$( ".datepicker" ).datepicker();
});


