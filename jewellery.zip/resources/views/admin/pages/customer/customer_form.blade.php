@include('admin.main.header')

<div class="mrg_tp"></div>
<div class="dashboard_min">
    <div class="container-fluid">
        <div class="dashboard_panel">

            <div class="dashboard_right w-100">
                <div class="das_right_inr ">
                    <div class="">
                        <ul class="">
                            <h2>
                                <li class=" mt-5"><a href="order-form.html">Add Customer</a></li>
                            </h2>

                        </ul>
                    </div>
                    <div class="das_frm_panel ">
                        <form action="{{ route('add_worker') }}" method="post" enctype="multipart/form-data">
                            {{ csrf_field() }}
                            <div class="das_frm_bx mt-5">
                                <div class="frm_inp_body">
                                    <div class="row">

                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Customer Name</span>
                                                <input type="text" placeholder="Customer Name" name="cname" required>
                                            </div>
                                        </div>

                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Customer Phone</span>
                                                <input type="text" placeholder="Customer Phone" name="phone" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>ITEM</span>
                                                <input type="text" placeholder="Item" name="item" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Pan No</span>
                                                <input type="text" placeholder="Pan No" name="place" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>AADHAAR CARD</span>
                                                <input type="number" placeholder="Customer Aadhaar" name="adhar"
                                                    required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>ADVANCE PAYMENT</span>
                                                <input type="text" placeholder="Advance Payment" name="adpay" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Email</span>
                                                <input type="email" placeholder="Customer email" name="email" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>BALANCE AMOUNT</span>
                                                <input type="text" placeholder="Balance Amount" name="bamount" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>GST NO</span>
                                                <input type="text" placeholder="Gst No" name="gstno" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>ADDRESS</span>
                                                <input type="text" placeholder="Address" name="address" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>ORDER ID</span>
                                                <input type="text" placeholder="Order Id" name="orderid" required>
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>STATUS</span>
                                                <select name="status">
                                                    <option value="1">COMPLETED</option>
                                                    <option value="2">PENDING</option>
                                                </select>
                                                <!-- <em class="drp_cc"><img src="assets/images/drop.png" alt=""></em> -->
                                            </div>
                                        </div>
                                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
                                            <div class="uplodimg">
                                                <span class="uplode_spa"><small>Customer Image</small></span>
                                                <div class="uplodimgfil">
                                                    <input type="file" name="customer_image" id="file-1"
                                                        class="inputfile inputfile-1"
                                                        data-multiple-caption="{count} files selected" required>
                                                    <label for="file-1">Drag and Drop or <b>Browse</b> to upload
                                                        <em><img src="{{url('public')}}/assets/images/gall.png"
                                                                alt=""></em>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class=" cc_top_btn">
                                            <button style="border:none;margin-top:123px;height:53px;text-align:center;"
                                                type="submit" class="btn_cc mx-5">Submit
                                                <em><img src="{{ url('public') }}/assets/images/btn_icon.png" alt=""
                                                    class="mt-2"></em></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


@include('admin.main.footer');
