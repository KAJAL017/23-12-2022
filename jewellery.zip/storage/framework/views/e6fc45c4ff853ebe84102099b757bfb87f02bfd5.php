<?php echo $__env->make('admin.main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="mrg_tp"></div>

<div class="dashboard_min">
    <div class="container-fluid">
        <div class="worker_list_sec">
            <div class="worker_list_top" style="cursor: pointer">
                <div class="worker_list_left">
                    <div class="worker_list_input" >
                        <a href="<?php echo e(route('customer_form')); ?>"><input type="submit" placeholder="Add Worker"
                                value="Add Customer" style="cursor: pointer"></a>
                        <em class="sh_img"><img src="<?php echo e(url('public')); ?>/assets/images/plus.png" alt=""></em>
                    </div>
                </div>
            </div>
            <div class="worker_list_panel">
                <div class="worker_list_tab_hed">
                    <div class="row">
                        
                        <div class="col "><b>Actions</b></div>
                        <div class="col "><b>Aadhaar</b></div>
                        <div class="col "><b>Place</b></div>
                        <div class="col "><b>Phone</b></div>
                        <div class="col "><b>Working ID</b></div>
                        <div class="col "><b>Mail ID</b></div>
                        <div class="col "><b>User Name</b></div>
                    </div>
                </div>
                
                
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.main.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\jewellery\resources\views/admin/pages/customer/customers.blade.php ENDPATH**/ ?>