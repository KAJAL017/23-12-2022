const ctx = document.getElementById('myChart');


const options = {
  layout: { autoPadding: true },
  hover: { intersect: false },
  // borderWidth: 100,
  backdropPadding: 0,
  padding: 0,
  plugins: {
    legend: {
      display: true,
    },
    tooltip: {
      caretPadding: 10,
      caretPosition: 'right',
      caretX: 0,
      caretY: 0,
      intersect: false,
      mode: 'index',
      // xAlign: 'right',
      yAlign: 'center',
      position: 'average',
      // callbacks: {
      //   //This removes the tooltip title
      //   // title: function () {},
      //   label: ({ raw }) => {
      //     return raw
      //   },
      // },
      //this removes legend color
      displayColors: false,
      padding: 3,
      pointHitRadius: 5,
      pointRadius: 1,
      caretSize: 10,
      backgroundColor: 'rgba(255,255,255,.9)',
      // borderColor: `red`,
      borderWidth: 1,
      bodyFont: {
        family: 'Inter',
        size: 12,
      },
      bodyColor: '#303030',
      titleFont: {
        family: 'Inter',
      },
      titleColor: 'rgba(0,0,0,0.6)',
    },
  },
  scales: {
    y: {
      ticks: {
        display: true,
      },
      grid: {
        drawBorder: false,
        borderWidth: 0,
        drawTicks: false,
        color: 'transparent',
        width: 0,
        backdropPadding: 0,
      },
      drawBorder: false,
      drawTicks: false,
    },
    x: {
      ticks: {
        display: true,
      },
      grid: {
        drawBorder: false,
        borderWidth: 0,
        drawTicks: false,
        display: false,
      },
    },
  },
  responsive: true,
  maintainAspectRatio: false,
}

const labels = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

const data = {
  labels,
  datasets: [
    {
      label: 'Sum of Total Gross Weight',
      data: [29, 58, 30, 40, 5, 35, 0, 18, 9, 30, 45, 38],
      backgroundColor: '#006CFF',
      minBarLength: 50,
      borderRadius: 100,
      borderSkipped: false,
    },
    {
      label: 'Sum of Approx Gms',
      data: [25, 10, 33, 46, 5, 60, 0, 22, 9, 80, 14, 44],
      backgroundColor: '#9680FF',
      minBarLength: 50,
      borderRadius: 100,
      borderSkipped: false,
    },
  ],
}


const myChart = new Chart(ctx, {
    type: 'bar',
    data,
    options,
});








// 22222222222


// const options = {
//   layout: { autoPadding: true },
//   hover: { intersect: false },
//   // borderWidth: 100,
//   backdropPadding: 0,
//   padding: 0,
//   plugins: {
//     legend: {
//       display: true,
//     },
//     tooltip: {
//       caretPadding: 10,
//       caretPosition: 'right',
//       caretX: 0,
//       caretY: 0,
//       intersect: false,
//       mode: 'index',
//       // xAlign: 'right',
//       yAlign: 'center',
//       position: 'average',
//       // callbacks: {
//       //   //This removes the tooltip title
//       //   // title: function () {},
//       //   label: ({ raw }) => {
//       //     return raw
//       //   },
//       // },
//       //this removes legend color
//       displayColors: false,
//       padding: 3,
//       pointHitRadius: 5,
//       pointRadius: 1,
//       caretSize: 10,
//       backgroundColor: 'rgba(255,255,255,.9)',
//       // borderColor: `red`,
//       borderWidth: 1,
//       bodyFont: {
//         family: 'Inter',
//         size: 12,
//       },
//       bodyColor: '#303030',
//       titleFont: {
//         family: 'Inter',
//       },
//       titleColor: 'rgba(0,0,0,0.6)',
//     },
//   },
//   scales: {
//     y: {
//       ticks: {
//         display: true,
//       },
//       grid: {
//         drawBorder: false,
//         borderWidth: 0,
//         drawTicks: false,
//         color: 'transparent',
//         width: 0,
//         backdropPadding: 0,
//       },
//       drawBorder: false,
//       drawTicks: false,
//     },
//     x: {
//       ticks: {
//         display: true,
//       },
//       grid: {
//         drawBorder: false,
//         borderWidth: 0,
//         drawTicks: false,
//         display: false,
//       },
//     },
//   },
//   responsive: true,
//   maintainAspectRatio: false,
// }

// const labels = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

// const data = {
//   labels,
//   datasets: [
//     {
//       label: 'Sum of Total Gross Weight',
//       data: [29, 58, 30, 40, 5, 35, 0, 18, 9, 30, 45, 38],
//       backgroundColor: '#006CFF',
//       minBarLength: 50,
//       borderRadius: 100,
//       borderSkipped: false,
//     },
//     {
//       label: 'Sum of Approx Gms',
//       data: [25, 10, 33, 46, 5, 60, 0, 22, 9, 80, 14, 44],
//       backgroundColor: '#9680FF',
//       minBarLength: 50,
//       borderRadius: 100,
//       borderSkipped: false,
//     },
//   ],
// }


// const myChart2 = new Chart(ctx2, {
//     type: 'bar',
//     data,
//     options,
// });







new Chart(document.querySelector('#myChart2').getContext('2d'), {
        type: 'bar',
        data: {
            labels: ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"],
            datasets: [{
                label: '',
                data: [32,28,23,61,73,34,46,42,64,85,102,96],
                fill: true,
                borderRadius: 100,
                borderSkipped: false,
                borderColor: '#fff',
                backgroundColor: '#5eb8ff',                 

                datalabels: {
                    display: false
                }
            }]
                },
                options:{
                  scales: {
          x: {
            grid: {
              display: false,
              drawOnChartArea:false
            }
          },
          y: {
            grid: {
              display: false,
              drawOnChartArea:false,
            }
          }
        }
        }
    });


new Chart(document.querySelector('#myChart3').getContext('2d'), {
        type: "doughnut",
        data: {
            datasets: [{
                label: 'Sales',
                data: [83, 34, 14, 32],
                fill: true,
                borderRadius: 0,
                indexLabelFontSize: 17,
                indexLabel: "{label} - #percent%",
                toolTipContent: "<b>{label}:</b> {y} (#percent%)",
                borderColor: '#fff',
                backgroundColor : ["#f9ca17", "#ffffff", "#6b7e94", "#e7f6fe" ],
                 

                datalabels: {
                    display: false
                }
            }]
                },

        //         options:{
        //           scales: {
        //   x: {
        //     grid: {
        //       display: false,
        //       drawOnChartArea:false
        //     }
        //   },
        //   y: {
        //     grid: {
        //       display: false,
        //       drawOnChartArea:false,
        //     }
        //   }
        // }
        // }
    });


new Chart(document.querySelector('#myChart4').getContext('2d'), {
        type: "doughnut",
        data: {
            datasets: [{
                label: 'Sales',
                data: [30, 34, 14],
                fill: true,
                borderRadius: 0,
                indexLabelFontSize: 17,
                indexLabel: "{label} - #percent%",
                toolTipContent: "<b>{label}:</b> {y} (#percent%)",
                borderColor: '#fff',
                backgroundColor : ["#595959", "#9c88fa", "#0066f0" ],
                 

                datalabels: {
                    display: false
                }
            }]
                },

        //         options:{
        //           scales: {
        //   x: {
        //     grid: {
        //       display: false,
        //       drawOnChartArea:false
        //     }
        //   },
        //   y: {
        //     grid: {
        //       display: false,
        //       drawOnChartArea:false,
        //     }
        //   }
        // }
        // }
    });



new Chart(document.querySelector('#myChart5').getContext('2d'), {
        type: 'bar',
        data: {
            labels: ["Sai Gold", "Ananya Jewels", "Bijou Raayan", "Rohini Diamonds", "Shree Diamonds", "Marlecha Diamonds", "NSSJ", "Panchrathnam"],
            datasets: [{
                label: '',
                data: [32,28,23,61,73,34,46,42],
                fill: true,
                borderRadius: 10,
                borderSkipped: false,
                borderColor: '#fff',
                backgroundColor: '#006cff5c',                 

                datalabels: {
                    display: false
                }
            },
            {
                label: '',
                data: [10,40,30,50,80,10,30,20],
                fill: true,
                borderRadius: 10,
                borderSkipped: false,
                borderColor: '#fff',
                backgroundColor: '#006cff40',
                tension:0.4,                 
                type: 'line',
                datalabels: {
                    display: false
                }
            }]
                },
                options:{
                  scales: {
          x: {
            grid: {
              display: false,
              drawOnChartArea:false
            }
          },
          y: {
            grid: {
              display: false,
              drawOnChartArea:false,
            }
          }
        }
        }
    });



new Chart(document.querySelector('#myChart6').getContext('2d'), {
        type: 'bar',
        data: {
            labels: ["Ring", "Earrings", "Nose Pins", "Gold", "Braclets", "Chains", "Marlecha Diamonds"],
            datasets: [{
                label: '',
                data: [32,26,64,64,36,42,58],
                fill: true,
                borderRadius: 10,
                borderSkipped: false,
                borderColor: '#fff',
                backgroundColor: '#006cff5c',                 

                datalabels: {
                    display: false
                }
            },
            {
                label: '',
                data: [10,40,30,50,80,10,30,20],
                fill: true,
                borderRadius: 10,
                borderSkipped: false,
                borderColor: '#fff',
                backgroundColor: '#006cff40',
                tension:0.4,                 
                type: 'line',
                datalabels: {
                    display: false
                }
            }]
                },
                options:{
                  scales: {
          x: {
            grid: {
              display: false,
              drawOnChartArea:false
            }
          },
          y: {
            grid: {
              display: false,
              drawOnChartArea:false,
            }
          }
        }
        }
    });
