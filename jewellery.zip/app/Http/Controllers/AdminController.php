<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class AdminController extends Controller
{

    public function login(Request $req){
        // return 1;
        $where = array();
        $where['email'] = $req->email;
        $where['password'] = $req->password;
        $check = DB::table('users')->where($where)->first();
        if(empty($check)){
            return redirect()->back()->with('error','User Not Found!');
        }
        else{
            if(!empty($check)){
                if($req->password === $check->password) {
                    // session()->flush();
                    $req->session()->put('id',$check->id);
                    $req->session()->put('role',$check->role);
                    return redirect()->route('order_form')->with('success','Login Successfully');
                }
            else{
                    return redirect()->back()->with('error','Password Not Matched');
                }
            }
        }
    }
    public function logout(){
        session()->forget(['id']);
        return redirect('/')->with('success','Logout Successfully');
    }
    public function index(){
        return view('admin.pages.index');
    }
    public function order_form(){
        return view('admin.pages.order.order_form');
    }
    public function store_order(Request $req){

     $insert = array();
     $insert['client_name'] =  $req->cname;
     $insert['unique_id'] = $req->unique_id;
     $insert['date'] = $req->date;
     $insert['mcolor'] = $req->metalcolor;
     $insert['appx_gram'] = $req->appx_weight;
     $insert['comments'] = $req->comment;

     if($req->file('img')) {
        $file=$req->file('img');
        $image =time().$file->getClientOriginalName();
        $file->move(public_path('uploads'), $image);
        $insert['image'] = $image;
    }
    $lastid = DB::table('orders')->insertGetId($insert);
    $i=0;
    if($req->pname)


    {
        foreach($req->pname as $key => $file){
            $data = array();
            $data['order_id'] = $lastid;
            $data['product_name'] = $req->pname[$key];
            $data['size'] = $req->size[$key];
            $data['karat'] = $req->karat[$key];
            $data['mcolor'] = $req->mcolor[$key];
            $data['appxgram'] = $req->apxgram[$key];
            DB::table('order_details')->insert($data);
            $i++;
        }
        }
        return redirect()->back()->with('success','Order Successfull');

        }
        public function order_history(){
            $data['order'] = DB::table('orders')->get();
            return view('admin.pages.order.order_history',$data);
        }
        public function view_order_form($id){
            $where['id'] = $id;
            $order = DB::table('orders')->where($where)->first();
            $order_details = DB::table('order_details')->where('order_id',$id)->get();
            $data = compact('order','order_details');
            return view('admin.pages.order.view_order_form',$data);
        }
        public function worker(){
            $worker = DB::table('worker')->get();
            $data = compact('worker');
            return view('admin.pages.worker.worker')->with($data);
        }
        public function worker_form(){
            return view('admin.pages.worker.worker_form');
        }
        public function add_worker(Request $req){

            $insert =  array();
            $insert['name'] = $req->name;
            $insert['phone'] = $req->phone;
            $insert['place'] = $req->place;
            $insert['adhar'] = $req->adhar;
            $insert['working_id'] = $req->working_id;
            $insert['email'] = $req->email;

            if($req->file('worker_iamge')) {
                $file=$req->file('worker_iamge');
                $image =time().$file->getClientOriginalName();
                $file->move(public_path('uploads'), $image);
                $insert['worker_iamge'] = $image;
            }

           if($req->update_id){
                DB::table('worker')->where('id',$req->update_id)->update($insert);
                return redirect()->route('worker')->with('success','Worker Update SuccessFullly');

           }else{
               DB::table('worker')->insert($insert);
               return redirect()->route('worker')->with('success','Worker Added SuccessFullly');
           }


        }

         public function delete_worker($id){
            $where = array();
            $where['id'] = $id ;
            DB::table('worker')->where($where)->delete();
            return redirect()->back()->with('success','Worker Remove SuccessFully');
         }

         public function edit_worker($id){
            $where = array();
            $where['id'] = $id ;
            $worker = DB::table('worker')->where($where)->first();
            $data = compact('worker');
            return view('admin.pages.worker.edit_worker')->with($data);
         }
        public function customers(){
            
            return view('admin.pages.customer.customers');

        }
        public function customer_form(){
            
            return view('admin.pages.customer.customer_form');

        }




}
