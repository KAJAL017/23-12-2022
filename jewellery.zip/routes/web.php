<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[AdminController::class,'index'])->name('index');

// ORDER ROUTES HERE
Route::get('order_form',[AdminController::class,'order_form'])->name('order_form');
Route::post('store_order',[AdminController::class,'store_order'])->name('store_order');
Route::get('order_history',[AdminController::class,'order_history'])->name('order_history');
Route::get('view_order_form/{id}',[AdminController::class,'view_order_form'])->name('view_order_form');

// Worker Route Here
Route::get('worker',[AdminController::class,'worker'])->name('worker');
Route::post('add_worker',[AdminController::class,'add_worker'])->name('add_worker');
Route::get('worker_form',[AdminController::class,'worker_form'])->name('worker_form');
Route::get('delete_worker/{id}',[AdminController::class,'delete_worker'])->name('delete_worker');
Route::get('edit_worker/{id}',[AdminController::class,'edit_worker'])->name('edit_worker');

