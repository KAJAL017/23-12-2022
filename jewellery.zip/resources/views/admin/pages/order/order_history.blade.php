@include('admin.main.header');

<div class="mrg_tp"></div>

<div class="dashboard_min">
    <div class="container-fluid">
        <div class="worker_list_sec">
            {{-- <div class="worker_list_top">
                <div class="worker_list_left">
                    <div class="worker_list_input">
                        <a href="{{ route('worker_form') }}"><input type="submit" placeholder="Add Worker"
                                value="Add Worker"></a>
                        <em class="sh_img"><img src="{{ url('public') }}/assets/images/plus.png" alt=""></em>
                    </div>
                </div>
            </div> --}}
            <div class="worker_list_panel">
                <div class="worker_list_tab_hed">
                    <div class="row">
                        {{-- <div class="col "><b>#</b></div> --}}
                        <div class="col "><b>Actions</b></div>
                        <div class="col "><b>Client Name</b></div>
                        <div class="col "><b>Uniqui Id</b></div>
                        <div class="col "><b>Date</b></div>
                        <div class="col "><b>Metal Color</b></div>
                        {{-- <div class="col "><b></b></div>
                        <div class="col "><b>User Name</b></div> --}}
                    </div>
                </div>
                @foreach ($order as $item)
                <div class="worker_list_tab_itm">
                    <div class="row">
                        <div class="col">
                            <span class="hide_big">Actions</span>
                            <div class="ac_di">
                                <ul>
                                    <li><a href="{{ route('view_order_form',[$item->id]) }}"><img src="{{ url('public') }}/assets/images/action1.png" alt=""></a>
                                    </li>
                                    {{-- <li><a href="{{ route('edit_worker',[$item->id]) }}"><img src="{{ url('public') }}/assets/images/action2.png" alt=""></a></li>
                                    <li ><a href="{{ route('delete_worker',[$item->id]) }}"><img src="{{ url('public') }}/assets/images/action3.png" alt=""></a></li> --}}
                                </ul>
                            </div>
                        </div>
                        <div class="col">
                            <p>{{ $item->client_name  }}</p>
                        </div>
                        <div class="col">
                            <p>{{ $item->unique_id  }}</p>
                        </div>
                        <div class="col">
                            <p>{{ $item->date  }}</p>
                        </div>
                        <div class="col">
                            <p> @if ($item->mcolor==1) RED @elseif($item->mcolor==2) YELLOW @endif </p>
                        </div>


                    </div>
                </div>
                @endforeach
                {{-- <div class="phar_pagination">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <li class="page-item disabled">
                                <a class="page-link" href="#" tabindex="-1"><i class="fa fa-angle-left"></i>Prev</a>
                            </li>
                            <li class="page-item active"><a class="page-link" href="#">1</a></li>
                            <li class="page-item "><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">4</a></li>
                            <li class="page-item"><a class="page-link" href="#">5</a></li>
                            <li class="page-item">
                                <a class="page-link" href="#" tabindex="-1">Next<i class="fa fa-angle-right"></i></a>
                            </li>
                        </ul>
                    </nav>
                </div> --}}
            </div>
        </div>
    </div>
</div

@include('admin.main.footer');
