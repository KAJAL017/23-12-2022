
<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(url('public')); ?>/assets/js/jquerymin.js"></script>
<script src="<?php echo e(url('public')); ?>/assets/js/bootstrap.js"></script>
<script src="<?php echo e(url('public')); ?>/assets/js/jquery-ui.min.js"></script>
<script src="<?php echo e(url('public')); ?>/assets/js/custom.js"></script>
<script src="<?php echo e(url('public')); ?>/assets/js/datepicker.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- <script src="https://npmcdn.com/chart.js@latest/dist/chart.min.js"></script> -->
<script src="https://canvasjs.com/<?php echo e(url('public')); ?>/assets/script/canvasjs.min.js"></script>
<script src="<?php echo e(url('public')); ?>/assets/js/main.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    <?php if(session()->has('success')): ?>
            Swal.fire(
            '',
            '<?php echo e(session()->get('success')); ?>!',
            'success');
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
            Swal.fire(
            '',
            '<?php echo e(session()->get('error')); ?>!',
            'error');
    <?php endif; ?>
</script>

<input type="hidden" id="append_no" value="1">
<script>
function appendform(){
    var i = Number($("#append_no").val());
    $('#addappend').append("<div class='row mt-1 remove"+i+"' id='removelist'><div class='col-xl-3 col-lg-2 col-md-3 col-sm-12'><div class='input_bx'><span>Product Name</span><span class='multi-select-custom'></span><input type='text' placeholder='Enter Product Name' name='pname[]'></div></div><div class='col-lg-2 col-md-2 col-sm-12'><div class='input_bx'><span>Size</span><input type='text' placeholder='Enter Size' name='size[]'></div></div><div class='col-xl-2 col-lg-2 col-md-3 col-sm-12'><div class='input_bx'><span>Appx Gram</span><input type='text' placeholder='Enter Size' name='apxgram[]'></div></div><div class='col-xl-2 col-lg-4 col-md-3 col-sm-12'><div class='input_bx'><span>Metal colour</span><select name='mcolor[]'><option>Red</option><option>Yellow</option></select></div></div><div class='col-xl-2 col-lg-4 col-md-3 col-sm-12'><div class='input_bx'><span>Karat ( Purity )</span><select name='karat'><option>18K</option><option>22K</option></select></div></div><div class='col-md-1 mt-5'><div class='form-group'><button class='btn btn-primary' type='button' style='font-size: 20px; padding: 0px 10px;' onclick='appendform()'>+</button> <button class='btn btn-danger' type='button' style='font-size: 20px; padding: 0px 10px;' onclick='removeform("+i+")'>-</button></div></div></div>");
    $("#append_no").val(i+1);
}
function removeform(id){
    $(".remove"+id).remove();
}
</script>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel\jewellery\resources\views/admin/main/footer.blade.php ENDPATH**/ ?>