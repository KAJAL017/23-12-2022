<?php echo $__env->make('admin.main.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="mrg_tp"></div>

<div class="dashboard_min">
    <div class="container-fluid">
        <div class="dashboard_panel">
            <div class="dashboard_left">
                <div class="das_left_inr">
                    <div class="das_menu">
                        <h4> Order Book</h4>
                        <ul>
                            <li ><a href="<?php echo e(route('order_form')); ?>">Order Form</a></li>
                            <li><a href="<?php echo e(route('order_history')); ?>">Order History</a></li>
                            <li><a href="#url">Order Status</a></li>
                        </ul>
                    </div>
                    <div class="das_menu">
                        <h4> Manufacture</h4>
                        <ul>
                            <li><a href="manufacture-filling-form.html">Filing</a></li>
                            <li><a href="manufacture-mounting.html">Mounting</a></li>
                            <li><a href="manufacture-setting-form.html">Setting</a></li>
                            <li><a href="manufacture-final-polish.html">Final Polish</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="dashboard_right">
                <div class="das_right_inr">
                    <div class="das_tab_menu">
                        <ul>
                            <li><a href="order-form.html">Order Form</a></li>
                            <li class="actv"><a href="order-history.html">Order History</a></li>
                            <li><a href="#url">Order Status</a></li>
                        </ul>
                    </div>
                    <div class="das_frm_panel">
                        <form action="#" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="das_frm_bx">
                                <div class="frm_tp">
                                    <h4>Order No : 13202</h4>
                                </div>
                                <div class="frm_inp_top">
                                    <div class="row">
                                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Client Name</span>
                                                <input type="text" placeholder="Full Name" name="cname"
                                                    value="<?php echo e($order->client_name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Unique ID</span>
                                                <input type="text" value="<?php echo e($order->unique_id); ?>" name="unique_id">
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12">
                                            <div class="input_bx">
                                                <span>Date</span>
                                                <input type="text" class="datepicker" name="date"
                                                    value="<?php echo e($order->date); ?>">
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="frm_inp_body">
                               <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <div class="row">
                                <div class="col-xl-3 col-lg-2 col-md-3 col-sm-12">
                                    <div class="input_bx">
                                        <span>Product Name</span>
                                        <span class="multi-select-custom"></span>
                                        <input type="text"  value="<?php echo e($data->product_name); ?>" >
                                    </div>
                                </div>
                                <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12">
                                    <div class="input_bx">
                                        <span>Size</span>
                                        <input type="text" value="<?php echo e($data->size); ?>">
                                    </div>
                                </div>
                                <div class="col-xl-2 col-lg-2 col-md-3 col-sm-12">
                                    <div class="input_bx">
                                        <span>Appx Gram</span>
                                        <input type="text" value="<?php echo e($data->appxgram); ?>">
                                    </div>
                                </div>
                                <div class="col-xl-2 col-lg-4 col-md-3 col-sm-12">
                                    <div class="input_bx">
                                        <span>Metal colour</span>
                                        <select >
                                            <option <?php if($data->mcolor == 1): ?><?php echo e('selected'); ?> <?php endif; ?> >Red</option>
                                            <option <?php if($data->mcolor == 2): ?><?php echo e('selected'); ?> <?php endif; ?> >Yellow</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-xl-2 col-lg-4 col-md-3 col-sm-12">
                                    <div class="input_bx">
                                        <span>Karat ( Purity )</span>
                                        <select name="karat">
                                            <option <?php if($data->karat == 1): ?><?php echo e('selected'); ?> <?php endif; ?> >18K</option>
                                            <option  <?php if($data->karat == 2): ?><?php echo e('selected'); ?> <?php endif; ?>>22K</option>
                                        </select>
                                    </div>
                                </div>

                            </div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div id="addappend"></div>
                                    <div class="col-md-12">
                                        <div class="input_frm_b">
                                            <span>Metal Color</span>
                                            <div class="dedio_bt">
                                                <ul>
                                                    <?php if($order->mcolor==1): ?>
                                                    <li>
                                                        <input id="redio1" type="radio" checked value="1"
                                                            name="metalcolor">
                                                        <label for="redio1">Yellow</label>
                                                    </li>
                                                    <?php endif; ?>
                                                    <?php if($order->mcolor==2): ?>
                                                    <li>
                                                        <input id="redio2" type="radio" checked value="2"
                                                            name="metalcolor">
                                                        <label for="redio2">White</label>
                                                    </li>
                                                    <?php endif; ?>


                                                    <?php if($order->mcolor==3): ?>
                                                    <li>
                                                        <input id="redio3" type="radio" checked value="3"
                                                            name="metalcolor">
                                                        <label for="redio3">2 tone</label>
                                                    </li>
                                                    <?php endif; ?>
                                                    <?php if($order->mcolor==4): ?>
                                                    <li>
                                                        <input id="redio4" type="radio" checked value="4"
                                                            name="metalcolor">
                                                        <label for="redio4">3 tone</label>
                                                    </li>
                                                    <?php endif; ?>


                                                    <?php if($order->mcolor==4): ?>
                                                    <li>
                                                        <input id="redio5" type="radio" checked value=""
                                                            name="metalcolor">
                                                        <label for="redio5">Rose</label>
                                                    </li>
                                                    <?php endif; ?>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="container-fluid">
                                        <div class="row">
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                                                <div class="input_bx">
                                                    <span>Approx Weight Grams</span>
                                                    <input type="text" placeholder="Enter here" name="appx_weight"
                                                        value="<?php echo e($order->appx_gram); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 ">
                                                <div class="input_bx">
                                                    <span>Comments</span>
                                                    <input type="text" placeholder="Enter here" name="comment"
                                                        value="<?php echo e($order->comments); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="container-fluid mt-5">
                                        <div class="row">
                                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 ">
                                                <img src="<?php echo e(url('public/uploads')); ?>/<?php echo e($order->image); ?>" alt="">

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
        </form>
    </div>
</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('admin.main.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\jewellery\resources\views/admin/pages/order/view_order_form.blade.php ENDPATH**/ ?>