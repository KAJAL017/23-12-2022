<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Starlight Diamonds</title>
    <link href="<?php echo e(url('public')); ?>/assets/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo e(url('public')); ?>/assets/css/style.css" rel="stylesheet">
    <link href="<?php echo e(url('public')); ?>/assets/css/responsive.css" rel="stylesheet">
    <link href="<?php echo e(url('public')); ?>/assets/css/fonts.css" rel="stylesheet">
    <link href="<?php echo e(url('public')); ?>/assets/css/font-awesome/all.min.css" rel="stylesheet">
    <link href="<?php echo e(url('public')); ?>/assets/css/jquery-ui.css" rel="stylesheet">


</head>

<body>


    <header class="header_sec">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-light nav_top">
                <a class="navbar-brand" href="index.html"><img src="<?php echo e(url('public')); ?>/assets/images/logo1.png"
                        alt="logo" /></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <img src="<?php echo e(url('public')); ?>/assets/images/menu.png" alt="">
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <!-- <ul class="mr-auto">
			  	</ul> -->
                    <ul class="navbar-nav menu_sec">
                        <li><a href="index.html" class="das_ccs">Dashboard</a></li>
                        <li class="<?php echo e((request()->route()->named('customers')) ? 'actv' : ''); ?>"
                            ><a href="<?php echo e(route('customers')); ?>">Customers</a></li>
                        <li class="<?php echo e((request()->route()->named('worker')) ? 'actv' : ''); ?> <?php echo e((request()->route()->named('edit_worker')) ? 'actv' : ''); ?>"><a
                                href="<?php echo e(route('worker')); ?>">Worker</a></li>
                        <li class="<?php echo e((request()->route()->named('order_form')) ? 'actv' : ''); ?>"><a
                                href="<?php echo e(route('order_form')); ?>">Products</a></li>
                        <li class="<?php echo e((request()->route()->named('order_history')) ? 'actv' : ''); ?>"><a
                                href="<?php echo e(route('order_history')); ?>">History</a></li>
                    </ul>
                </div>
                <ul class="hed_top_img">
                    <li>
                        <a href="#url" class="noti">
                            <img src="<?php echo e(url('public')); ?>/assets/images/bell.png" alt="">
                            <em class="noti_dot">
                                <img src="<?php echo e(url('public')); ?>/assets/images/dot.png" alt="">
                            </em>
                        </a>
                    </li>
                    <li>
                        <a href="#" class="pic_pro">
                            <img src="<?php echo e(url('public')); ?>/assets/images/hed_img.png" alt="">
                        </a>
                    </li>
        </div>
        </nav>
        </div>
    </header>
<?php /**PATH C:\xampp\htdocs\jewellery\resources\views/admin/main/header.blade.php ENDPATH**/ ?>